"use client";

import { useState } from "react";
import Link from "next/link";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [faceId, setFaceId] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setLoading(true);
    setMessage(null);

    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, faceId }),
    });

    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error ?? "Unable to login");
    } else {
      window.location.href = data.redirect ?? "/dashboard";
    }
    setLoading(false);
  };

  return (
    <div className="mx-auto flex min-h-screen max-w-6xl flex-col gap-12 px-6 py-16 md:flex-row">
      <div className="flex-1 space-y-6 rounded-3xl border border-white/10 bg-black/30 p-8 shadow-glow">
        <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-700 text-xl font-bold text-black">
          AU
        </div>
        <div>
          <h1 className="text-3xl font-semibold text-white">Welcome back</h1>
          <p className="text-white/70">Sign in with your face, PIN, or password. Push alerts keep you updated after every action.</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <label className="block text-xs uppercase tracking-[0.3em] text-white/60">
            email or phone
            <input
              className="mt-2 w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-base text-white"
              placeholder="haruna@auwntech.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </label>
          <label className="block text-xs uppercase tracking-[0.3em] text-white/60">
            password
            <input
              type="password"
              className="mt-2 w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-base text-white"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          <div className="flex items-center justify-between text-sm text-white/70">
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={faceId} onChange={(e) => setFaceId(e.target.checked)} /> Face ID quick login
            </label>
            <Link href="#" className="text-auwn-accent">
              Forgot?
            </Link>
          </div>
          {message && <p className="text-sm text-red-400">{message}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-full bg-gradient-to-r from-teal-500 to-emerald-300 px-8 py-3 font-semibold text-black"
          >
            {loading ? "Checking..." : "Sign In"}
          </button>
        </form>
        <p className="text-center text-sm text-white/70">
          New here? <Link href="/signup" className="text-auwn-accent">Create Auwntech account</Link>
        </p>
        <div className="rounded-2xl border border-white/5 bg-white/[0.03] p-4 text-sm text-white/70">
          4 failed password tries → lock for 1 hour. Wrong PIN attempt on payments or transfers instantly suspends the session and alerts the admin.
        </div>
      </div>
      <div className="flex-1 rounded-3xl border border-white/10 bg-black/30 p-8 shadow-glow">
        <h2 className="text-2xl font-semibold text-white">Push-style notifications</h2>
        <p className="mt-2 text-white/70">Members see a toast for every activity. Admin adjustments, top-ups, suspensions, and receipts display here instantly.</p>
        <div className="mt-8 space-y-4">
          {[
            {
              title: "₦20,000 added by Admin",
              body: "Wallet credited. Reference ADM-2089",
            },
            {
              title: "PIN attempt blocked",
              body: "You entered the wrong transaction PIN. Session suspended until reset.",
            },
            {
              title: "Data bundle purchased",
              body: "5GB MTN sent to 0803 222 1111",
            },
          ].map((toast, index) => (
            <div key={index} className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
              <strong className="block text-white">{toast.title}</strong>
              <span className="text-sm text-white/70">{toast.body}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
