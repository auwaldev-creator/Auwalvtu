"use client";

import { useEffect, useMemo, useState } from "react";
import { NotificationStack, ToastMessage } from "@/components/NotificationStack";

interface WalletState {
  wallet_balance: number;
  airtime_balance: number;
  data_balance: number;
  account_number?: string;
}

interface Transaction {
  id: string;
  amount: number;
  kind: string;
  direction: "debit" | "credit";
  status: string;
  reference: string;
  metadata?: Record<string, any>;
  created_at: string;
  balance_before?: number;
  balance_after?: number;
}

export default function DashboardPage() {
  const [wallet, setWallet] = useState<WalletState | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [profile, setProfile] = useState<
    { full_name: string; account_number: string; role: string; status: string; bank_choice?: string }
  | null>(null);
  const [loading, setLoading] = useState(true);
  const [toastFeed, setToastFeed] = useState<ToastMessage[]>([]);
  const [action, setAction] = useState<{ kind: string; amount: string; pin: string; direction: "debit" | "credit" }>({
    kind: "airtime",
    amount: "",
    pin: "",
    direction: "debit",
  });
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const response = await fetch("/api/transactions", { cache: "no-store" });
      const data = await response.json();
      if (response.ok) {
        setWallet({
          wallet_balance: Number(data.wallet?.wallet_balance ?? 0),
          airtime_balance: Number(data.wallet?.airtime_balance ?? 0),
          data_balance: Number(data.wallet?.data_balance ?? 0),
        });
        setTransactions(data.transactions ?? []);
        setProfile(data.profile ?? null);
      }
      setLoading(false);
    };
    load();
  }, []);

  useEffect(() => {
    if (!transactions.length) return;
    const latest = transactions[0];
    const toast: ToastMessage = {
      id: latest.id ?? latest.reference,
      title: `${latest.direction === "credit" ? "Received" : "Sent"} ₦${latest.amount.toFixed(2)}`,
      body: `${latest.kind} • Ref ${latest.reference}`,
      tone: "success",
    };
    setToastFeed([toast]);
  }, [transactions]);

  const filteredTransactions = useMemo(() => transactions.slice(0, 5), [transactions]);

  const handleSubmit = async () => {
    setMessage(null);
    const body = {
      kind: action.kind,
      direction: action.direction,
      amount: Number(action.amount),
      pin: action.pin,
    };
    const response = await fetch("/api/transactions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error ?? "Unable to run transaction");
      return;
    }
    setMessage("Transaction successful");
    setAction({ ...action, amount: "", pin: "" });
    const refresh = await fetch("/api/transactions", { cache: "no-store" });
    const refreshed = await refresh.json();
    setWallet({
      wallet_balance: Number(refreshed.wallet?.wallet_balance ?? 0),
      airtime_balance: Number(refreshed.wallet?.airtime_balance ?? 0),
      data_balance: Number(refreshed.wallet?.data_balance ?? 0),
    });
    setTransactions(refreshed.transactions ?? []);
  };

  if (loading) {
    return <p className="p-10 text-center text-white/60">Loading dashboard...</p>;
  }

  return (
    <div className="space-y-8 px-6 py-12">
      <NotificationStack feed={toastFeed} />
      <header className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-sm text-white/50">Wallet overview</p>
          <h1 className="text-3xl font-semibold text-white">Welcome {profile?.full_name ?? "member"}</h1>
        </div>
        <div className="rounded-full border border-white/15 px-5 py-2 text-sm text-white/70">
          Account #{profile?.account_number ?? "•••••"}
        </div>
      </header>
      <section className="grid gap-4 md:grid-cols-3">
        <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
          <p className="text-sm text-white/60">Wallet balance</p>
          <p className="mt-2 text-3xl font-semibold text-white">₦{wallet?.wallet_balance.toFixed(2)}</p>
          <button className="mt-6 w-full rounded-full border border-white/20 px-4 py-2 text-sm text-white">
            Add Money
          </button>
        </div>
        <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
          <p className="text-sm text-white/60">Airtime vault</p>
          <p className="mt-2 text-3xl font-semibold text-white">₦{wallet?.airtime_balance.toFixed(2)}</p>
        </div>
        <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
          <p className="text-sm text-white/60">Data bundles</p>
          <p className="mt-2 text-3xl font-semibold text-white">{wallet?.data_balance ?? 0} GB</p>
        </div>
      </section>

      <section className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-semibold text-white">Quick actions</h2>
            <p className="text-white/60">PIN required for every debit.</p>
          </div>
          <div className="flex flex-wrap gap-3">
            {["airtime", "data", "transfer"].map((kind) => (
              <button
                key={kind}
                onClick={() => setAction({ ...action, kind, direction: "debit" })}
                className={`rounded-full px-5 py-2 text-sm ${
                  action.kind === kind ? "bg-gradient-to-r from-teal-500 to-emerald-300 text-black" : "border border-white/20 text-white"
                }`}
              >
                {kind === "airtime" ? "Buy Airtime" : kind === "data" ? "Buy Data" : "Internal Transfer"}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-4">
          <label className="text-sm text-white/70">
            Amount (₦)
            <input
              className="mt-2 w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3"
              value={action.amount}
              onChange={(e) => setAction({ ...action, amount: e.target.value })}
            />
          </label>
          <label className="text-sm text-white/70">
            Direction
            <select
              className="mt-2 w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3"
              value={action.direction}
              onChange={(e) => setAction({ ...action, direction: e.target.value as "debit" | "credit" })}
            >
              <option value="debit">Debit</option>
              <option value="credit">Credit</option>
            </select>
          </label>
          <label className="text-sm text-white/70">
            PIN
            <input
              className="mt-2 w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3"
              maxLength={6}
              value={action.pin}
              onChange={(e) => setAction({ ...action, pin: e.target.value.replace(/[^0-9]/g, "") })}
            />
          </label>
          <div className="flex items-end">
            <button
              onClick={handleSubmit}
              className="w-full rounded-2xl bg-gradient-to-r from-teal-500 to-emerald-300 px-4 py-3 font-semibold text-black"
            >
              Execute
            </button>
          </div>
        </div>
        {profile?.account_number && (
          <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.02] p-4 text-sm text-white/70">
            <p className="font-semibold text-white">Add money via virtual account</p>
            <p>Bank: {profile.bank_choice ?? "Auwntech Partner"}</p>
            <p>Account name: {profile.full_name}</p>
            <p>Account number: {profile.account_number}</p>
            <p className="text-white/50">Funds reflect instantly and trigger a push notification.</p>
          </div>
        )}
        {message && <p className="mt-3 text-sm text-emerald-300">{message}</p>}
      </section>

      <section className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
        <div className="flex flex-wrap items-center justify-between">
          <h2 className="text-2xl font-semibold text-white">Recent transactions</h2>
        </div>
        <div className="mt-6 space-y-4">
          {filteredTransactions.map((tx) => (
            <div key={tx.id ?? tx.reference} className="flex flex-wrap items-center justify-between rounded-2xl border border-white/10 bg-white/[0.02] px-4 py-3">
              <div>
                <p className="text-base text-white">
                  {tx.direction === "credit" ? "Received" : "Sent"} ₦{Number(tx.amount).toFixed(2)}
                </p>
                <p className="text-sm text-white/60">
                  {tx.kind} • {new Date(tx.created_at).toLocaleString()}
                </p>
              </div>
              <div className="text-right">
                <span className="rounded-full bg-white/10 px-3 py-1 text-xs uppercase tracking-wide text-white">
                  {tx.status}
                </span>
                <p className="text-xs text-white/40">Ref {tx.reference}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
