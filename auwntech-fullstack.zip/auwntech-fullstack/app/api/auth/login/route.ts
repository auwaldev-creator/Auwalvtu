import { NextResponse } from "next/server";
import { z } from "zod";
import { getAdminClient } from "@/lib/supabaseAdmin";
import { compareSecret } from "@/lib/security";
import { createSessionCookie, sessionCookieName } from "@/lib/session";

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  faceId: z.boolean().optional(),
});

const MAX_PASSWORD_ATTEMPTS = 4;

export async function POST(request: Request) {
  try {
    const payload = loginSchema.parse(await request.json());
    const supabase = getAdminClient();

    const { data: profile, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("email", payload.email.toLowerCase())
      .maybeSingle();

    if (error) {
      console.error(error);
      return NextResponse.json({ error: "Unable to read profile" }, { status: 500 });
    }

    if (!profile) {
      return NextResponse.json({ error: "Account not found" }, { status: 404 });
    }

    if (profile.suspended_until && new Date(profile.suspended_until) > new Date()) {
      return NextResponse.json(
        {
          error: "Account suspended",
          details: `Try again after ${new Date(profile.suspended_until).toLocaleString()}`,
        },
        { status: 423 }
      );
    }

    const validPassword = await compareSecret(payload.password, profile.password_hash);
    if (!validPassword) {
      const failedCount = (profile.failed_login_count ?? 0) + 1;
      const updates: Record<string, any> = {
        failed_login_count: failedCount,
        last_failed_login_at: new Date().toISOString(),
      };
      if (failedCount >= MAX_PASSWORD_ATTEMPTS) {
        const resumeAt = new Date(Date.now() + 60 * 60 * 1000);
        updates.status = "suspended";
        updates.suspended_until = resumeAt.toISOString();
        await supabase.from("admin_alerts").insert({
          user_id: profile.id,
          category: "password_lock",
          message: `${profile.full_name} locked out after repeated wrong passwords`,
        });
      }
      await supabase.from("profiles").update(updates).eq("id", profile.id);
      return NextResponse.json({ error: "Wrong password" }, { status: 401 });
    }

    await supabase
      .from("profiles")
      .update({ failed_login_count: 0, last_failed_login_at: null, status: "active", suspended_until: null })
      .eq("id", profile.id);

    const sessionCookie = createSessionCookie({ id: profile.id, role: profile.role });
    const response = NextResponse.json({ success: true, redirect: "/dashboard" });
    response.headers.set("Set-Cookie", sessionCookie);
    return response;
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
